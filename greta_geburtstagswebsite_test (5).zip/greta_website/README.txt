Greta-Geburtstagswebsite

1. Entpacke den ZIP-Ordner.
2. Öffne https://app.netlify.com/drop
3. Ziehe den Ordner "greta_website" mit der index.html in das Feld.
4. Netlify erstellt eine öffentliche URL. Kopiere diese URL.
5. Schicke mir die URL; daraus kann ich dir den endgültigen QR-Code erstellen.

Die Website enthält Startseite und Brief in einer Datei. Der Weiter-Button ist vorerst ein Platzhalter für das nächste Kapitel.
